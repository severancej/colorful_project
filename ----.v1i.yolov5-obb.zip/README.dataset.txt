# 식단사진 > 2022-11-10 9:52pm
https://universe.roboflow.com/section4project/-uc7wg

Provided by a Roboflow user
License: CC BY 4.0

